
  # Personal Portfolio Website

  This is a code bundle for Personal Portfolio Website. The original project is available at https://www.figma.com/design/f1a8U3PFi7JT8jUvHsbnE5/Personal-Portfolio-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  